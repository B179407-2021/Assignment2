#!/usr/local/bin/python3

################## Initiating Stage

###### Import modules
import os

###### Get user defined information
protein = input("Please enter your interested protein family\n")
group = input("Please enter your targeted taxonomic group\n")
print("Thank you. Now, in the process of Fetching data.\n")

###### Input test dataset information
test_protein = "glucose-6-phosphatase"
taxon_group = "Birds"

###### Get current working directory
my_path = os.getcwd()

###### Use edirect to get protein family of interest  

query = taxon_group+" [Organism] AND "+test_protein
print("Current Task:")
print("Searching targeted protein family under user-defined taxonmic group")
cmd = "esearch -db protein -query '{}' | efetch -format fasta > searching_result.fasta".format(query)
subprocess.call(cmd, shell=True)
print("Task Status: Accomplished")
print("Searching results are now saved under searching_result.fasta\nThanks for waiting.")

###### List all the species for user to choose

with open("searching_result.fasta") as searching_result:
        result = searching_result.read().rstrip("\n")
results = result.splitlines(True)

###### Get unique species and its counts
species_list = []
for line in results:
        if line.startswith(">") and "partial" not in line.split(" "):
                        species = line.split("[")[1]
                        species_list.append(species[:-2])
print("\nExcluding partial sequences, there are {} species in total.".format(len(set(species_list))))
print("Species and its number of apperance are listed as follows")
species_counts = {}
for element in set(species_list):
        counts = species_list.count(element)
        species_counts[element] = counts
for key in sorted(species_counts, key=species_counts.get, reverse = True):
        print(key, ": ", species_counts[key])
print("Species listed above are the peptide sequences in searching_result.fasta, which are not partial.\n")

###### Ask user is there any species that user wants to exclude:
excluded_list = []
while True:
	exclude = input("Is there any species that you want to exclude?\n")
        if exclude.upper() not in ["YES","NO"]:
                print("\nPlease enter yes or no.")
        else:
             	break
if exclude.upper() =="YES":
        species_upper = [x.upper() for x in species_list]
        while True:
                name = input("Please input the name of this species.(Input one name at a time).\nPlease press enter when you finish entering all the species.\n")
                if name.upper() in species_upper:
                        location = species_upper.index(name.upper())
                        excluded_list.append(species_list[location])
                elif name == "":
                        break
                else:
                     	print("Sorry. This species is not in the list above")
print("Thanks for the information.")
print("The species showed below will not appear in the following analysing process.")
[print(x) for x in excluded_list]

###### Ask user whether user wants to process predicted sequences or not

while True:
	predicted = input("\nDo you also want to analyse predicted sequences?(Please enter yes or no).\n")
        if predicted.upper() not in ["YES","NO"]:
                print("\nPlease enter yes or no.")
        else:
             	break

with open("user_defined.fasta","w") as new_fasta:
        for sequence in result.split(">"):
                if not ([sequence.split("]")[0].endswith(x) for x in excluded_list] or "partial" not in sequence.split(" ")):
                        if predicted.upper() =="YES":
                                sequence_need = ">"+sequence
                                new_fasta.write(sequence_need)
                        elif "PREDICTED:" not in sequence.split(" "):
                                sequence_need = ">"+sequence
                                new_fasta.write(sequence_need)

###### Cluster and Plot Conservation
print("Current Task:")
print("Conducting multiple alignment.")
os.system("clustalo -i user_defined.fasta -o cluster.msf --outfmt=msf")
print("Task Status: Accomplished")
print("Multiple alignment results are now saved under cluster.msf\nThanks for waiting.")

print("Current Task:")
print("Based on the alignment results, draw a plot of conservation.")
os.system("plotcon -sformat msf cluster.msf -graph cps")
print("Task Status: Accomplished")
print("Conservation plot is now saved under plotcon.ps\nThanks for waiting.")

###### Scanning PROSITE database for motif in user_defined fasta file and get motifs information
print("Current Task:")
print("Scanning protein sequences with motifs in the PROSITE database.")
os.system("psiblast -query user_defined.fasta -db -num_iteration= -evalue= -out motifpattern.out -out_pssm=")
print("Task Status: Accomplished")
print("Conservation plot is now saved under plotcon.ps\nThanks for waiting.")
